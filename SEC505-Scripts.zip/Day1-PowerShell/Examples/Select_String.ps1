select-string 'K5.*[efg]lex' $env:windir\inf\*.inf |
format-table path,line -autosize
