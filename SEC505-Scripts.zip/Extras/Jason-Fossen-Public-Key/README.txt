

This folder contains a copy of the OpenPGP public
key of Jason Fossen, the SEC505 course author.

This key may be used with applications such as:

    Pgp4Win     (https://www.gpg4win.org)
    Mailvelope  (https://www.mailvelope.com)
    GnuPG       (https://www.gnupg.org)



