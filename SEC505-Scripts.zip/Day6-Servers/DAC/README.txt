This DAC folder is for scripts for Dynamic Access Control (DAC).

DAC is an access control technology similar to NTFS permissions
first introduced with Server 2012.


