# To list the classes available in a particular namespace, such as "root\CIMv2":

get-wmiobject -query "select * from meta_class" -namespace "root\cimv2"


